let cryptos = {
  BTC: "Bitcoin",
  BAT: "Basic attention token",
  LTC: "Litecoin",
  XRP: "Ripple",
};

module.exports = cryptos;
